-- Model, skin, chosen groups and material overrides travel with the prop after its owner is gone.
return function(runtime)
    local E={Type="anim",Base="base_anim",PrintName="Dropped shoe / 脱下的鞋",Spawnable=false,RenderGroup=RENDERGROUP_BOTH}
    function E:SetupDataTables()
        self:NetworkVar("String",0,"SourcePath")
        self:NetworkVar("String",1,"ShoeParts")
        self:NetworkVar("String",2,"MaterialMap")
        self:NetworkVar("Bool",0,"LeftFoot")
        self:NetworkVar("Bool",1,"Worn")
        self:NetworkVar("Int",0,"SourceSkin")
        self:NetworkVar("Float",0,"ShoeScale")
    end
    if SERVER then
        function E:Initialize()
            self:SetModel("models/props_junk/PopCan01a.mdl")
            self:DrawShadow(false)
            if self:GetWorn() then self:SetMoveType(MOVETYPE_NONE) self:SetSolid(SOLID_NONE) return end
            local shape=self.RFShape
            if not shape then return end
            local scale=self:GetShoeScale()
            local pad=Vector(0.08,0.08,0.08)
            self:PhysicsInitBox(shape.lo*scale-pad,shape.hi*scale+pad)
            self:SetCollisionBounds(shape.lo*scale-pad,shape.hi*scale+pad)
            self:SetMoveType(MOVETYPE_VPHYSICS)
            self:SetSolid(SOLID_VPHYSICS)
            self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
            self:EnableCustomCollisions(true)
            local p=self:GetPhysicsObject()
            if IsValid(p) then p:SetMass(0.6) p:SetMaterial("rubber") p:Wake() end
        end
    else
        function E:Draw()
            local info=runtime.profile(self:GetSourcePath())
            if not info then return end
            local parts=self:GetShoeParts()
            if parts~=self.RFKey then
                self.RFSelection=util.JSONToTable(parts)
                self.RFKey=parts
            end
            if not self.RFSelection then return end
            local side=self:GetLeftFoot() and "left" or "right"
            local shape=runtime.shape(info,side,self.RFSelection,self:GetSourceSkin())
            if not shape then return end
            local scale=self:GetShoeScale()
            self:SetRenderBounds(shape.lo*scale,shape.hi*scale)
            local overrides=self:GetMaterialMap()
            if self.RFOverridesKey~=overrides then
                self.RFOverrides=util.JSONToTable(overrides) or {}
                self.RFOverridesKey=overrides
            end
            local matrix=Matrix()
            matrix:SetAngles(self:GetAngles()) matrix:SetTranslation(self:GetPos())
            matrix:SetScale(Vector(scale,scale,scale))
            local col=self:GetColor()
            local r,g,b=render.GetColorModulation()
            local blend=render.GetBlend()
            render.SetColorModulation(col.r/255,col.g/255,col.b/255)
            render.SetBlend(col.a/255)
            cam.PushModelMatrix(matrix,true)
            for _,batch in ipairs(shape.batches) do
                local custom=self:GetMaterial()
                local mat=custom~="" and custom or self.RFOverrides["m"..batch.id] or batch.path
                render.SetMaterial(Material(mat))
                batch.mesh:Draw()
            end
            cam.PopModelMatrix()
            render.SetColorModulation(r,g,b) render.SetBlend(blend)
        end
        -- Some original shoe materials use transparency. Draw each mesh once in this pass.
        E.DrawTranslucent=E.Draw
        E.Draw=function() end
    end
    scripted_ents.Register(E,"rf_runtime_shoe")
end
