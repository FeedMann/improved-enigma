-- Use the standard citizen sleeves and hands for a consistent two-hand interaction.
local action
local arms={}
local function removeArms()
    for _,ent in pairs(arms) do if IsValid(ent) then ent:Remove() end end
    arms={}
    action=nil
end
net.Receive("rf_shoe_grab",function()
    local ply,rag,left,start=net.ReadEntity(),net.ReadEntity(),net.ReadBool(),net.ReadFloat()
    if ply~=LocalPlayer() then return end
    removeArms()
    action={rag=rag,side=left and "L" or "R",start=start}
end)
local function arm(side)
    if IsValid(arms[side]) then return arms[side] end
    local ent=ClientsideModel("models/weapons/c_arms_citizen.mdl",RENDERGROUP_OPAQUE)
    if not IsValid(ent) then return end
    ent:SetNoDraw(true)
    ent:SetModelScale(1.25,0)
    ent:SetBodygroup(1,0)
    local wrist=ent:LookupBone("ValveBiped.Bip01_"..side.."_Hand")
    if not wrist then ent:Remove() return end
    ent.RFWrist=wrist
    arms[side]=ent
    return ent
end
local function active()
    return action and IsValid(action.rag) and LocalPlayer():Alive() and CurTime()-action.start<1.35
end
hook.Add("PreDrawViewModel","RF_HideWeaponWhilePulling",function()
    if active() and not LocalPlayer():ShouldDrawLocalPlayer() then return true end
end)
hook.Add("Think","RF_ClearGrabHands",function() if action and not active() then removeArms() end end)
hook.Add("ShutDown","RF_ClearGrabHands",removeArms)
hook.Add("PostDrawOpaqueRenderables","RF_DrawGrabHands",function(depth,sky)
    if depth or sky or not active() or LocalPlayer():ShouldDrawLocalPlayer() then return end
    local rag=action.rag
    local id=rag:LookupBone("ValveBiped.Bip01_"..action.side.."_Foot")
    local m=id and rag:GetBoneMatrix(id)
    if not m then return end
    local pos=m:GetTranslation()
    local up=Vector(0,0,1)
    local eye,view=EyePos(),EyeAngles()
    local t=math.max(0,CurTime()-action.start)
    local reach=math.EaseInOut(math.Clamp(t/0.42,0,1),0.5,0.5)*(1-math.Clamp((t-1.10)/0.25,0,1))
    local toward=eye-pos
    toward.z=0
    toward:Normalize()
    for _,which in ipairs({"L","R"}) do
        local ent=arm(which)
        if IsValid(ent) then
            local sign=which=="L" and -1 or 1
            local lateral=view:Right()*sign
            local rest=eye+view:Forward()*9+lateral*6-up*10
            local pull=which=="R" and math.Clamp((t-0.70)/0.45,0,1) or 0
            local target=LerpVector(reach,rest,pos+lateral*3.1+toward*(3.8+pull*9)+up*(which=="L" and 2 or -1))
            local elbow=eye+view:Forward()*10+lateral*10-up*13
            local forward=(target-elbow):GetNormalized()
            ent:SetPos(eye) ent:SetAngles(angle_zero)
            for i=0,ent:GetBoneCount()-1 do
                local n=ent:GetBoneName(i)
                if n:find("_"..which.."_Finger",1,true) then
                    ent:ManipulateBoneAngles(i,Angle(0,0,sign*17*reach))
                end
            end
            ent:SetupBones()
            local w=ent:GetBoneMatrix(ent.RFWrist)
            local function part(name)
                local id=ent:LookupBone("ValveBiped.Bip01_"..which.."_"..name)
                return id and ent:GetBoneMatrix(id)
            end
            local middle,forearm=part("Finger2"),part("Forearm")
            if w and middle and forearm then
                local wrist=w:GetTranslation()
                local palm=(middle:GetTranslation()-wrist):GetNormalized()
                local desired=(-lateral*0.70-toward*0.65+up*(which=="L" and 0.12 or 0.30)):GetNormalized()
                local function remap(src,srcDir,dst,dstDir)
                    local a,b=Matrix(),Matrix()
                    a:SetTranslation(src) a:SetAngles(srcDir:Angle())
                    b:SetTranslation(dst) b:SetAngles(dstDir:Angle())
                    return b*a:GetInverse()
                end
                local hand=remap(wrist,palm,target,desired)
                local fore=forearm:GetTranslation()

                local length=fore:Distance(wrist)
                -- Keep the actual elbow and wrist geometry contiguous at distant targets.
                local elbowWorld=target-forward*length
                local limb=remap(fore,(wrist-fore):GetNormalized(),elbowWorld,forward)
                local upper=part("UpperArm")
                local upperTransform=upper and remap(upper:GetTranslation(),(fore-upper:GetTranslation()):GetNormalized(),
                    elbowWorld-forward*fore:Distance(upper:GetTranslation()),forward)
                local matrices={}
                for i=0,ent:GetBoneCount()-1 do matrices[i]=ent:GetBoneMatrix(i) end
                for i=0,ent:GetBoneCount()-1 do
                    local b=matrices[i]
                    if b then
                        local n=ent:GetBoneName(i)
                        if n:find("_"..which.."_",1,true) then
                            local transform=(n:find("Finger") or n:find("Hand") or n:find("Wrist")) and hand
                                or n:find("Forearm") and limb or upperTransform
                            if transform then ent:SetBoneMatrix(i,transform*b) end
                        else
                            local hidden=Matrix()
                            hidden:SetTranslation(eye-view:Forward()*8-up*18)
                            hidden:SetScale(Vector(0.001,0.001,0.001))
                            ent:SetBoneMatrix(i,hidden)
                        end
                    end
                end
                render.SetLightingOrigin(target)
                render.SuppressEngineLighting(true)
                local light=render.ComputeLighting(target,up)
                local r,g,b=math.Clamp(light.x,0.45,1),math.Clamp(light.y,0.45,1),math.Clamp(light.z,0.45,1)
                render.ResetModelLighting(r,g,b)
                ent:DrawModel()
                render.SuppressEngineLighting(false)
                render.SetLightingOrigin(eye)
            end
        end
    end
end)
