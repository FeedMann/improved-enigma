local runtime=include("rf_auto_footwear/geometry.lua")
include("rf_auto_footwear/entity.lua")(runtime)
local bones={left="ValveBiped.Bip01_L_Foot",right="ValveBiped.Bip01_R_Foot"}
local other={left="right",right="left"}
local function profile(rag)
    return runtime.profile(rag:GetModel())
end

if CLIENT then
    include("rf_auto_footwear/hands.lua")
    return
end

util.AddNetworkString("rf_shoe_grab")
local chance=CreateConVar("rf_shoes_chance","30",bit.bor(FCVAR_ARCHIVE,FCVAR_REPLICATED),"NPC 死亡时掉一只鞋的概率 (%)",0,100)
local actions={}
local function foot(rag,side)
    local id=rag:LookupBone(bones[side])
    if not id then return end
    local idx=rag:TranslateBoneToPhysBone(id)
    if idx<0 or rag:TranslatePhysBoneToBone(idx)~=id then return end
    local phys=rag:GetPhysicsObjectNum(idx)
    if IsValid(phys) then return phys,id end
end

local function wearable(rag,side)
    if not foot(rag,side) or (rag.RFShoeRemoved and rag.RFShoeRemoved[side]) then return end
    local keep=rag.RFShoeAttached and rag.RFShoeAttached[side]
    if IsValid(keep) then return keep.RFSelection end
    return runtime.select(profile(rag),rag,side)
end

local function createShoe(rag,side,item,worn,existing)
    local info=profile(rag)
    local phys,id=foot(rag,side)
    local skin=IsValid(existing) and existing:GetSourceSkin() or rag:GetSkin()
    local shape=runtime.shape(info,side,item,skin)
    if not shape or not phys then return end
    local shoe=ents.Create("rf_runtime_shoe")
    if not IsValid(shoe) then return end
    shoe.RFShape=shape shoe.RFSelection=item
    shoe:SetSourcePath(info.path)
    shoe:SetShoeParts(util.TableToJSON(item))
    shoe:SetSourceSkin(skin) shoe:SetLeftFoot(side=="left")
    shoe:SetWorn(worn) shoe:SetShoeScale(rag:GetModelScale())
    local overrides={}
    for index in pairs(info.materials) do
        local m=rag:GetSubMaterial(index)
        if m and m~="" then overrides["m"..index]=m end
    end
    shoe:SetMaterialMap(IsValid(existing) and existing:GetMaterialMap() or util.TableToJSON(overrides))
    shoe:SetPos(phys:GetPos()) shoe:SetAngles(phys:GetAngles())
    shoe:Spawn()
    shoe:SetColor(rag:GetColor()) shoe:SetMaterial(rag:GetMaterial())
    -- Dynamic geometry is reconstructed from this snapshot, outside the stock duplicator format.
    shoe.DoNotDuplicate=true
    if worn then
        shoe:FollowBone(rag,id)
        shoe:SetLocalPos(vector_origin) shoe:SetLocalAngles(angle_zero)
        rag:DeleteOnRemove(shoe)
    elseif not IsValid(shoe:GetPhysicsObject()) then
        shoe:Remove() return
    end
    return shoe
end

local function sharesGroup(item,remaining)
    if not remaining then return false end
    for _,a in ipairs(item.parts) do
        for _,b in ipairs(remaining.parts) do
            if a.id==b.id then return true end
        end
    end
    return false
end

local function detach(rag,side)
    local item=wearable(rag,side)
    if not item then return end
    local existing=rag.RFShoeAttached and rag.RFShoeAttached[side]
    local shoe=createShoe(rag,side,item,false,existing)
    if not IsValid(shoe) then return end
    local opposite=other[side]
    local remaining=wearable(rag,opposite)
    -- A shared shoe or decoration group must remain visible on the other foot.
    if not IsValid(existing) and sharesGroup(item,remaining) then
        local keep=createShoe(rag,opposite,remaining,true)
        if not IsValid(keep) then shoe:Remove() return end
        rag.RFShoeAttached=rag.RFShoeAttached or {}
        rag.RFShoeAttached[opposite]=keep
        for _,part in ipairs(remaining.parts) do rag:SetBodygroup(part.id,part.off) end
    end
    for _,part in ipairs(item.parts) do rag:SetBodygroup(part.id,part.off) end
    if IsValid(existing) then existing:Remove() rag.RFShoeAttached[side]=nil end
    rag.RFShoeRemoved=rag.RFShoeRemoved or {}
    rag.RFShoeRemoved[side]=true
    return shoe
end

local function pickFoot(ply)
    local tr=ply:GetEyeTrace()
    local rag=tr.Entity
    if not IsValid(rag) then return end
    if not rag:IsRagdoll() and IsValid(rag:GetParent()) then rag=rag:GetParent() end
    if not rag:IsRagdoll() or not profile(rag) then return end
    local nearest,score=nil,16^2
    for _,side in ipairs({"left","right"}) do
        local phys=foot(rag,side)
        if phys then
            local d=phys:GetPos():DistToSqr(tr.HitPos)
            if d<score then nearest,score=side,d end
        end
    end
    if nearest and wearable(rag,nearest) and ply:EyePos():DistToSqr(tr.HitPos)<=100^2 then return rag,nearest end
end

local function finish(ply,a)
    if IsValid(a.shoe) then
        local p=a.shoe:GetPhysicsObject()
        if IsValid(p) then p:EnableMotion(true) p:Wake() end
    end
    if IsValid(a.rag) and a.rag.RFShoeUser==ply then a.rag.RFShoeUser=nil end
    actions[ply]=nil
end

local function begin(ply,rag,side)
    if actions[ply] or IsValid(rag.RFShoeUser) then return end
    local item=wearable(rag,side)
    if not item then return end
    local info=profile(rag)
    local skin=rag:GetSkin()
    local opposite=other[side]
    local remaining=wearable(rag,opposite)
    -- Validate both pieces before showing a grab: hiding a paired group also
    -- requires the replacement for the shoe that stays on the other foot.
    if not runtime.shape(info,side,item,skin) or
        (sharesGroup(item,remaining) and not runtime.shape(info,opposite,remaining,skin)) then
        ply:ChatPrint("这个模型的鞋组无法生成独立鞋子。")
        return
    end
    local phys=foot(rag,side)
    if not phys then return end
    local dir=ply:EyePos()-phys:GetPos()
    dir.z=0
    dir:Normalize()
    local a={rag=rag,side=side,start=CurTime(),phys=phys,base=phys:GetPos(),angle=phys:GetAngles(),dir=dir}
    actions[ply]=a
    rag.RFShoeUser=ply
    net.Start("rf_shoe_grab")
    net.WriteEntity(ply) net.WriteEntity(rag) net.WriteBool(side=="left") net.WriteFloat(a.start)
    net.SendPVS(rag:GetPos())
    ply:DoAnimationEvent(ACT_GMOD_GESTURE_ITEM_PLACE)
    return true
end

hook.Add("KeyPress","RF_ShoeUse",function(ply,key)
    if key~=IN_USE or not ply:Alive() or ply:InVehicle() then return end
    local rag,side=pickFoot(ply)
    if rag then begin(ply,rag,side) end
end)
hook.Add("PlayerUse","RF_BlockRagdollPickup",function(ply,ent)
    local a=actions[ply]
    if a and (ent==a.rag or ent==a.shoe or ent:GetParent()==a.rag) then return false end
end)
hook.Add("Think","RF_ShoePull",function()
    for ply,a in pairs(actions) do
        local t=CurTime()-a.start
        if not IsValid(ply) or not ply:Alive() or not IsValid(a.rag) or not IsValid(a.phys)
            or ply:EyePos():DistToSqr(a.phys:GetPos())>125^2 then
            finish(ply,a)
        else
            local lift=math.EaseInOut(math.Clamp(t/0.58,0,1),0.5,0.5)
            if a.phys:IsMotionEnabled() and t<1.08 then
                a.phys:Wake()
                local goal=a.base+(a.dir*3+Vector(0,0,11))*lift
                local delta=goal-a.phys:GetPos()
                local distance=math.min(delta:Length(),80*engine.TickInterval())
                a.phys:SetPos(a.phys:GetPos()+delta:GetNormalized()*distance,true)
                a.phys:SetVelocityInstantaneous(vector_origin)
            end
            if t>=0.70 and not a.pulled then
                a.pulled=true
                a.shoe=detach(a.rag,a.side)
                if IsValid(a.shoe) then
                    a.shoe:GetPhysicsObject():EnableMotion(false)
                    a.shoe:EmitSound("physics/cardboard/cardboard_box_impact_soft1.wav",48,115,0.35)
                else
                    ply:ChatPrint("这只鞋未能取下，请检查布娃娃当前的鞋组。")
                end
            end
            if t>=1.35 then
                finish(ply,a)
            elseif IsValid(a.shoe) then
                local p=a.shoe:GetPhysicsObject()
                if IsValid(p) then
                    local pull=math.Clamp((t-0.70)/0.45,0,1)
                    p:SetPos(a.phys:GetPos()+(a.dir*9-Vector(0,0,2))*pull,true)
                    p:SetAngles(a.phys:GetAngles(),true)
                end
            end
        end
    end
end)

hook.Add("EntityTakeDamage","RF_ServerFootwearRagdolls",function(npc)
    if npc:IsNPC() and profile(npc) then npc:SetShouldServerRagdoll(true) end
end)
hook.Add("CreateEntityRagdoll","RF_DeathShoe",function(npc,rag)
    if not npc:IsNPC() or not IsValid(rag) or not profile(npc) then return end
    local pct=chance:GetFloat()
    if pct<=0 or (pct<100 and math.Rand(0,100)>=pct) then return end
    local choices={}
    for _,side in ipairs({"left","right"}) do
        local item=runtime.select(profile(npc),npc,side)
        if item then choices[#choices+1]=side end
    end
    if #choices==0 then return end
    local side=choices[math.random(#choices)]
    timer.Simple(0,function()
        if not IsValid(rag) then return end
        local shoe=detach(rag,side)
        if IsValid(shoe) then
            local phys=shoe:GetPhysicsObject()
            local source=foot(rag,side)
            local v=source:GetVelocity()
            phys:SetVelocity(v:GetNormalized()*math.min(v:Length(),85)+VectorRand()*11+Vector(0,0,12))
        end
    end)
end)
