-- Read only the selected LOD0 shoe meshes from the mounted Source model.
-- All offsets below are relative to their respective studiohdr/VTX structures.
local M={}
local profiles,shapes={},{}
local function stream(path,handles)
    local f=assert(file.Open(path,"rb","GAME"),path)
    handles[#handles+1]=f
    local size=f:Size()
    local function at(pos,bytes)
        assert(pos>=0 and pos+bytes<=size,"invalid offset")
        f:Seek(pos)
        return f
    end
    return {
        i=function(p) return at(p,4):ReadLong() end,
        u=function(p) return at(p,2):ReadUShort() end,
        byte=function(p) return at(p,1):ReadByte() end,
        str=function(p) return at(p,1):Read(math.min(256,size-p)):match("^[^%z]*") end,
        float=function(p) return at(p,4):ReadFloat() end,
        raw=function(p,n) return at(p,n):Read(n) end
    }
end
local function read(fn)
    local handles={}
    local ok,value=pcall(fn,handles)
    for _,f in ipairs(handles) do f:Close() end
    if ok then return value end
    if GetConVar("developer"):GetBool() then print("[Ragdoll Footwear] "..tostring(value)) end
end
local function bounded(n,max) assert(n>=0 and n<=max,"invalid count") return n end
local words={"footwear","sneakers","sneaker","sandals","sandal","shoes","shoe","boots","boot","heels","heel","slippers","slipper","靴子","鞋子","鞋","靴","くつ","シューズ","ブーツ"}
local details={ribbon=true,flower=true,toering=true,lace=true,laces=true,bow=true,buckle=true,["鞋带"]=true}
local function kind(name)
    local n=name:lower():gsub("%.smd$",""):match("([^/\\]+)$") or ""
    n=n:gsub("[%s%p]","")
    for _,word in ipairs(words) do
        local a,b=n:find(word,1,true)
        if a then
            local pre,post=n:sub(1,a-1),n:sub(b+1)
            local side
            local function strip(s)
                for _,key in ipairs({"left","right","左","右","l","r"}) do
                    if s:sub(1,#key)==key and (s==key or details[s:sub(#key+1)]) then
                        side=(key=="left" or key=="l" or key=="左") and "left" or "right"
                        return s:sub(#key+1)
                    end
                end
                return s
            end
            pre=strip(pre) post=strip(post)
            if pre=="" and (post=="" or details[post]) then return side or "both",post~="" end
        end
    end
end
local function bare(n)
    n=n:lower():gsub("%.smd$","")
    return n:find("barefoot",1,true) or n:find("feet",1,true) or n:find("legs",1,true) or n:find("裸足",1,true) or n:find("赤脚",1,true)
end
local function describe(path,handles)
    local d=stream(path,handles)
    assert(d.raw(0,4)=="IDST" and (d.i(4)==48 or d.i(4)==49))
    local info={path=path,groups={},feet={},materials={},dirs={},skins={},crc=d.i(8)}
    local main=false
    for i=0,bounded(d.i(232),256)-1 do
        local p=d.i(236)+i*16
        local name=d.str(p+d.i(p))
        local selector,extra=kind(name)
        local on,off,blank={},nil,nil
        local parts={}
        local count=bounded(d.i(p+4),256)
        for j=0,count-1 do
            local q=p+d.i(p+12)+j*148
            local sub=d.str(q)
            parts[j]=q
            if d.i(q+72)==0 then blank=blank or j
            elseif bare(sub) then off=off or j
            else
                local subside,subextra=kind(sub)
                if selector or subside then
                    on[j]=true
                    if not selector and subside then
                        -- Infer from explicit submodel names only, never from an arbitrary outfit.
                        parts.selector=subside parts.extra=subextra
                    end
                end
            end
        end
        off=off or blank
        selector=selector or parts.selector
        if selector and off~=nil and next(on) then
            local group={id=i,selector=selector,extra=extra or parts.extra or false,on=on,off=off,parts=parts}
            info.groups[#info.groups+1]=group
            if not group.extra then main=true end
        end
    end
    if not main then return end
    for i=0,bounded(d.i(156),1024)-1 do
        local p=d.i(160)+i*216
        local n=d.str(p+d.i(p)):lower()
        local side=n=="valvebiped.bip01_l_foot" and "left" or n=="valvebiped.bip01_r_foot" and "right"
        if side then
            local m=Matrix()
            for r=1,3 do for c=1,4 do m:SetField(r,c,d.float(p+96+((r-1)*4+c-1)*4)) end end
            info.feet[side]={matrix=m,center=m:GetInverse():GetTranslation()}
        end
    end
    if not info.feet.left or not info.feet.right then return end
    for i=0,bounded(d.i(204),4096)-1 do
        local p=d.i(208)+64*i
        info.materials[i]=d.str(p+d.i(p)):gsub("\\","/")
    end
    for i=0,bounded(d.i(212),128)-1 do
        info.dirs[#info.dirs+1]=d.str(d.i(d.i(216)+4*i)):gsub("\\","/"):gsub("/*$","/")
    end
    local refs=bounded(d.i(220),4096)
    for s=0,bounded(d.i(224),256)-1 do
        info.skins[s]={}
        for j=0,refs-1 do info.skins[s][j]=d.u(d.i(228)+(s*refs+j)*2) end
    end
    return info
end
function M.profile(path)
    if not path or path=="" then return end
    path=path:lower()
    if profiles[path]==nil then profiles[path]=read(function(h) return describe(path,h) end) or false end
    return profiles[path] or nil
end
function M.select(info,rag,side)
    if not info then return end
    local parts,main={},nil
    for _,g in ipairs(info.groups) do
        local active=rag:GetBodygroup(g.id)
        if (g.selector==side or g.selector=="both") and g.on[active] then
            parts[#parts+1]={id=g.id,sub=active,off=g.off}
            if not g.extra then
                if main then return end
                main=g.id
            end
        end
    end
    if main then return {parts=parts,group=main} end
end
local function geometry(info,side,selection,skin,handles)
    local path=info.path
    local base=path:sub(1,-5)
    local d=stream(path,handles)
    local v=stream(base..".vvd",handles)
    local x=stream(base..".dx90.vtx",handles)
    assert(v.raw(0,4)=="IDSV" and v.i(4)==4 and x.i(0)==7 and v.i(8)==info.crc and x.i(16)==info.crc)
    local fix={}
    local cursor=0
    for i=0,bounded(v.i(48),65536)-1 do
        local p=v.i(52)+12*i
        local n=bounded(v.i(p+8),1000000)
        fix[#fix+1]={cursor,cursor+n,v.i(p+4)}
        cursor=cursor+n
    end
    local vertexStart=v.i(56)
    local function remap(idx)
        if #fix==0 then return idx end
        local lo,hi=1,#fix
        while lo<=hi do
            local mid=math.floor((lo+hi)/2)
            local f=fix[mid]
            if idx<f[1] then hi=mid-1 elseif idx>=f[2] then lo=mid+1 else return f[3]+idx-f[1] end
        end
        error("missing fixup")
    end
    local bind=info.feet[side].matrix
    local basis=bind:GetTranslation()
    local same=info.feet[side].center
    local opposite=info.feet[side=="left" and "right" or "left"].center
    local cache={}
    local geom={batches={},count=0,lo=Vector(1e5,1e5,1e5),hi=Vector(-1e5,-1e5,-1e5)}
    local function vertex(index)
        if cache[index] then return cache[index] end
        local p=vertexStart+48*remap(index)+16
        local original=Vector(v.float(p),v.float(p+4),v.float(p+8))
        local pos=bind*original
        local out={pos=pos,score=original:DistToSqr(same)-original:DistToSqr(opposite)}
        if CLIENT then
            out.normal=(bind*Vector(v.float(p+12),v.float(p+16),v.float(p+20))-basis):GetNormalized()
            out.u=v.float(p+24) out.v=v.float(p+28)
        end
        cache[index]=out
        return out
    end
    local row=info.skins[skin] or info.skins[0]
    local mainCount=0
    for _,part in ipairs(selection.parts) do
        local g
        for _,entry in ipairs(info.groups) do if entry.id==part.id then g=entry break end end
        assert(g and g.on[part.sub])
        local p=g.parts[part.sub]
        local start=d.i(p+84)/48
        local gx=x.i(32)+g.id*8
        local model=gx+x.i(gx+4)+8*part.sub
        local lod=model+x.i(model+4)
        assert(x.i(lod)==d.i(p+72))
        for m=0,bounded(d.i(p+72),4096)-1 do
            local mesh=p+d.i(p+76)+116*m
            local meshx=lod+x.i(lod+4)+9*m
            local first=start+d.i(mesh+12)
            local material=row[d.i(mesh)]
            local batch
            if CLIENT then batch=geom.batches[material] or {} geom.batches[material]=batch end
            for j=0,bounded(x.i(meshx),65536)-1 do
                local sg=meshx+x.i(meshx+4)+25*j
                local verts,indices=sg+x.i(sg+4),sg+x.i(sg+12)
                local function corner(i) return vertex(first+x.u(verts+9*x.u(indices+2*i)+4)) end
                for k=0,bounded(x.i(sg+16),65536)-1 do
                    local strip=sg+x.i(sg+20)+27*k
                    local n=bounded(x.i(strip),600000)
                    local offset=x.i(strip+4)
                    local list=bit.band(x.byte(strip+18),1)~=0
                    for i=0,n-3,list and 3 or 1 do
                        local flip=not list and i%2==1 and 1 or 0
                        local a,b,c=corner(offset+i+flip),corner(offset+i+1-flip),corner(offset+i+2)
                        if a~=b and b~=c and a~=c and (g.selector~="both" or a.score+b.score+c.score<=0) then
                            geom.count=geom.count+1
                            if g.id==selection.group then mainCount=mainCount+1 end
                            for _,vt in ipairs({a,b,c}) do
                                if not vt.measured then
                                    local p,lo,hi=vt.pos,geom.lo,geom.hi
                                    lo.x=math.min(lo.x,p.x) lo.y=math.min(lo.y,p.y) lo.z=math.min(lo.z,p.z)
                                    hi.x=math.max(hi.x,p.x) hi.y=math.max(hi.y,p.y) hi.z=math.max(hi.z,p.z)
                                    vt.measured=true
                                end
                                if batch then batch[#batch+1]=vt end
                            end
                        end
                    end
                end
            end
        end
    end
    if mainCount==0 then return end
    if CLIENT then
        local buffers={}
        for idx,batch in pairs(geom.batches) do
            local name=info.materials[idx]
            local path=name
            for _,dir in ipairs(info.dirs) do
                local candidate=(dir..name):gsub("^/+","")
                if file.Exists("materials/"..candidate..".vmt","GAME") then path=candidate break end
            end
            for start=1,#batch,60000 do
                local chunk={}
                for i=start,math.min(start+59999,#batch) do chunk[#chunk+1]=batch[i] end
                local buffer=Mesh()
                buffer:BuildFromTriangles(chunk)
                buffers[#buffers+1]={mesh=buffer,path=path,id=idx}
            end
        end
        geom.batches=buffers
    end
    return geom
end
function M.shape(info,side,selection,skin)
    local tags={}
    for _,part in ipairs(selection.parts) do tags[#tags+1]=part.id.."."..part.sub end
    local key=info.path..":"..side..":"..table.concat(tags,",")..":"..(CLIENT and skin or 0)
    local found=shapes[key]
    if not found then
        local shape=read(function(h) return geometry(info,side,selection,skin,h) end)
        if not shape then return end
        found={value=shape}
        shapes[key]=found
    end
    found.last=RealTime()
    return found.value
end
timer.Create("RF_RuntimeMeshCache",60,0,function()
    for key,e in pairs(shapes) do
        if RealTime()-e.last>120 then
            if CLIENT then for _,b in ipairs(e.value.batches) do b.mesh:Destroy() end end
            shapes[key]=nil
        end
    end
end)
return M
