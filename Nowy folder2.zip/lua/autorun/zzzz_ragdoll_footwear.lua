if SERVER then
    AddCSLuaFile()
    AddCSLuaFile("rf_auto_footwear/controller.lua")
    AddCSLuaFile("rf_auto_footwear/geometry.lua")
    AddCSLuaFile("rf_auto_footwear/entity.lua")
    AddCSLuaFile("rf_auto_footwear/hands.lua")
end

-- Sandbox builds its first Q menu before the deferred gameplay setup runs.
if CLIENT then
    hook.Add("AddToolMenuCategories", "RF_FootwearCategory", function()
        spawnmenu.AddToolCategory("Options", "Ragdoll Footwear", "Ragdoll Footwear")
    end)
    hook.Add("PopulateToolMenu", "RF_FootwearSettings", function()
        spawnmenu.AddToolMenuOption("Options", "Ragdoll Footwear", "RFFootwear", "布娃娃脱鞋", "", "", function(panel)
            panel:Help("靠近布娃娃，瞄准一只脚，按一次 E。")
            panel:NumSlider("NPC 死亡掉一只鞋的概率 (%)", "rf_shoes_chance", 0, 100, 0)
        end)
    end)
end

-- Older local builds registered the same interaction during autorun. Install this
-- release after that pass, including on a map change with an old GMA still mounted.
timer.Create("RF_InstallCurrentFootwear",0,1,function()
    include("rf_auto_footwear/controller.lua")
end)
